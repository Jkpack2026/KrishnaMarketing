KRISHNA MARKETING - PART 3

Added:
- Android 13+ notification permission
- Internet connectivity check
- Professional offline screen
- Retry button
- App version 1.1 / versionCode 2
- Previous Part 1 + Part 2 functionality retained

IMPORTANT:
This part only requests notification permission. Actual Firebase Cloud Messaging push notifications require an FCM server/token setup and are not claimed as completed here.
