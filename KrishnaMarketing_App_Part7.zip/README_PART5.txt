KRISHNA MARKETING - PART 5 - FCM READY

Added:
- Firebase Cloud Messaging dependency
- Native Firebase Messaging service
- Notification channel
- Notification display for notification/data payloads
- FCM token capture in local app storage
- Android notification permission from Part 3 retained
- Version 1.3 / versionCode 4

NOT FULLY ACTIVATED YET:
Native Android FCM needs google-services.json from the Firebase project.
See GOOGLE_SERVICES_REQUIRED.txt.

Once that file is placed in app/, enable the google-services plugin line
described there, sync Gradle, and build/test the app.
