KRISHNA MARKETING - PART 4

Added:
- Android 12+ native launch-screen configuration
- Adaptive app icon configuration
- Secure network security configuration (cleartext disabled)
- WebView load-error fallback to offline/retry screen
- App version 1.2 / versionCode 3
- Previous parts retained

BUILD:
Open the project in Android Studio and let Gradle sync.
Test on an Android phone before generating a release AAB.
