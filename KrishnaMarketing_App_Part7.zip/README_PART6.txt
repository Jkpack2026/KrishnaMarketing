KRISHNA MARKETING - PART 6

Part 6 adds native notification testing and keeps the FCM integration ready.
Because the supplied Firebase configuration is a Web App config, actual
Android FCM activation remains pending until google-services.json is supplied.

Version: 1.4
Package: com.krishnamarketing.app
Website: https://radhikamarketing.netlify.app/
